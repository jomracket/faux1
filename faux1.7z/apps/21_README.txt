21 - A GAME OF BLACKJACK

FROM THE APPLE1 SOFTWARE LIBRARY POSTED AT http://www.applefritter.com/node/6203 BY V.BRIEL 2005-01-25

Usage:
This progrm expects the APPLE1 Integer BASIC loaded in ROM at 0xE000.

Load ASCII Binary (faux1 and replica1):
Open 21.woz with text editor and paste ASCII hex file into the WOZON.
Enter E2B3R into WOZMON to warm start BASIC.
> RUN

-or-

Load ASCII BASIC (faux1 and replica1):
Enter E000R to cold start BASIC.
Open 21.bas with text editor and paste ASCII text file into the BASIC.
> RUN


2012-02-19
